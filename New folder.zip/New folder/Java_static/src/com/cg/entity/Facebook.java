package com.cg.entity;

public class Facebook 
{
	int id;
	int n=0;
	static int likes=0;
	Facebook(int id)
	{
		this.id=id;
	}
	
	void show(int id)
	{
		n++;
		System.out.println("id:"+id +" "+"n: "+n);
	}
	static void imgclick()
	{
		likes++;
		System.out.println("likes: "+likes);
	}
 public static void main(String[] args) {
	Facebook user1=new Facebook(101);
	user1.show(101);
	user1.imgclick();
	
	Facebook user2=new Facebook(102);
	user2.show(102);
	user2.imgclick();
	
	Facebook user3=new Facebook(103);
	user3.show(103);
	user3.imgclick();
}
}

package com.cg.person.inheritence;

public class Emp extends Person
{
 
double basicSal;

public Emp(int id, String name, double basicSal)
{
	super(id, name);
	this.basicSal = basicSal;
}
public void calc()
{
	double pf;
	double TA=5000;
	pf=(basicSal*12)/100;
	double totalSal=basicSal+TA-pf;
	System.out.println("total sal: "+totalSal);
}
@Override
public String toString() {
	return "Emp [basicSal=" + basicSal + ", id=" + id + ", name=" + name + "]";
}



}

package com.cg.person.inheritence;

public class TestInheritence 
{
public static void main(String[] args) 
{
	//Person p1=new Person(111,"Jay");
	//p1.calc();
	//ystem.out.println(p1);
	
	Emp e1=new Emp(112,"Vijay",12000.00);
	e1.calc();
	e1.show();
	System.out.println(e1);
	
	Salesman s1=new Salesman(111,"Rahul",13000);
	s1.calc();
	System.out.println(s1);
}
}

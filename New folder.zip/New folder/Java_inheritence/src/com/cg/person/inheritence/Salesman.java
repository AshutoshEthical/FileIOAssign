package com.cg.person.inheritence;

public  class Salesman extends Person{
	int commission;

	public Salesman(int id, String name, int commission) {
		super(id, name);
		this.commission = commission;
	}

	public void calc()
	{
		int tsal=commission+10;
		System.out.println("Total salary: "+tsal);
	}

	@Override
	public String toString() {
		return "Salesman [commission=" + commission + ", id=" + id + ", name=" + name + "]";
	}

	
	
}

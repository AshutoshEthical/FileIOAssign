package com.cg.jdbc;

import java.sql.SQLException;

//can be treated as UI which will connect with crud class to perform operations
public class JdbcStarter {
public static void main(String[] args) throws SQLException {
	Employee emp=new Employee();
	emp.setEmpId(5001);
	emp.setEmpName("Jack");
	emp.setSalary(50000);
	//creation of jdbc object anf invoking the add method and passing the emp object
	//new JdbcCrud().addEmployee(emp);
	//new JdbcCrud().updateEmployee(emp);
	//new JdbcCrud().deleteEmployee(emp);
	new JdbcCrud().fetchEmployee(5001);
}
}

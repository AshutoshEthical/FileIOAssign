package com.cg.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class JdbcCrud {

	Scanner sc=new Scanner(System.in);
	public void addEmployee(Employee e) throws SQLException{
		
		//load the driver
		//establish connection
		//prepare the statement
		//execute the statemnet
		//process the result
		
		//Class.forName(Emplyee.class);
		Connection conn=null;
		String url="jdbc:oracle:thin:@localhost:1521:xe";
			conn=DriverManager.getConnection(url,"system","Capgemini123");
			Statement st=conn.createStatement();
			int rows=st.executeUpdate("insert into employee_JDBC values("+e.getEmpId()+",'"+e.getEmpName()+"',"+e.getSalary()+")");
			System.out.println(rows);
			System.out.println("inserted successfully");
			conn.close();
		}

	
	public void fetchEmployee(int eid) throws SQLException {
		
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Connection conn=DriverManager.getConnection(url,"system","Capgemini123");
		Statement st=conn.createStatement();
		//ResultSet rs=st.executeQuery(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		PreparedStatement ps=conn.prepareStatement("select * from employee_jdbc where empid=?");
		ps.setInt(1, eid);
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			int id=rs.getInt("empId");
			String name=rs.getString(2);
			int sal=rs.getInt(3);
			System.out.println("eid "+ id);
			System.out.println("name "+name);
			System.out.println("salary "+sal);
		}
	}	
	
	/*public void updateEmployee(Employee e) throws SQLException {
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Connection conn=DriverManager.getConnection(url,"system","Capgemini123");
		Statement st=conn.createStatement();
		System.out.println("enter the value to be updated:");
		int uEmpId=sc.nextInt();
	    int rows=st.executeUpdate("update Employee_JDBC set EmpId="+uEmpId+" where EmpId="+e.getEmpId());
	    		//update Employee_JDBC set EmpId=5002,EmpName="Rahul",Salary=40000;
	    System.out.println("updated successfully");
	}*/
	
     /* public void deleteEmployee(Employee e) throws SQLException {
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Connection conn=DriverManager.getConnection(url,"system","Capgemini123");
		Statement st=conn.createStatement();
	    int rows=st.executeUpdate("delete from Employee_JDBC where EmpName='"+e.getEmpName()+"'");
	    System.out.println("deleted successfully");
	}*/
}


package com.cg.jdbc;

public class Employee 
{
  private Integer empId;
  private String empName;
  private Integer Salary;
public Employee(Integer empId, String empName, Integer salary) {
	super();
	this.empId = empId;
	this.empName = empName;
	Salary = salary;
}
public Employee() {
	super();
}
public Integer getEmpId() {
	return empId;
}
public void setEmpId(Integer empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public Integer getSalary() {
	return Salary;
}
public void setSalary(Integer salary) {
	Salary = salary;
}
  
  
}

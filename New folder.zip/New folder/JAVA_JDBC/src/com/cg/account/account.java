package com.cg.account;

public class account {
private Integer accountNo;
private Integer balance;
public account(Integer accountNo, Integer balance) {
	super();
	this.accountNo = accountNo;
	this.balance = balance;
}
public account() {
	super();
}
public Integer getAccountNo() {
	return accountNo;
}
public void setAccountNo(Integer accountNo) {
	this.accountNo = accountNo;
}
public Integer getBalance() {
	return balance;
}
public void setBalance(Integer balance) {
	this.balance = balance;
}

}

package com.cg.account;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.jdbc.Employee;

public class JdbcCrud 
{
public void addAccount(account a) throws SQLException{
		Connection conn=null;
		String url="jdbc:oracle:thin:@localhost:1521:xe";
			conn=DriverManager.getConnection(url,"system","Capgemini123");
			Statement st=conn.createStatement();
			int rows=st.executeUpdate("insert into Account values("+a.getAccountNo()+","+a.getBalance()+")");
			System.out.println(rows);
			System.out.println("inserted successfully");
			conn.close();
}

public void creditDebitAccount() throws SQLException
{
	Connection conn=null;
	String url="jdbc:oracle:thin:@localhost:1521:xe";
		conn=DriverManager.getConnection(url,"system","Capgemini123");
		conn.setAutoCommit(false);
		try
		{
		PreparedStatement debit=conn.prepareStatement("update account set balance=balance-? where accountno=?");
		PreparedStatement credit=conn.prepareStatement("update account set balance=balance+? where accountno=?");
		debit.setInt(1, 500);
		debit.setInt(2, 1001);
		credit.setInt(1, 500);
		credit.setInt(2, 1002);
		
		debit.executeUpdate();
		credit.executeUpdate();
		conn.commit();
		System.out.println("transaction successful");
		}
		catch(Exception e)
		{
			conn.rollback();
			
		}
		finally
		{
			conn.close();
		}
}
}

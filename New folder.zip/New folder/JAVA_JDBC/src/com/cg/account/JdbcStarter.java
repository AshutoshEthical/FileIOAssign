package com.cg.account;

import java.sql.SQLException;

public class JdbcStarter {
public static void main(String[] args) throws SQLException {
	account a1=new account();
	a1.setAccountNo(1001);
	a1.setBalance(50000);
	
	account a2=new account();
	a2.setAccountNo(1002);
	a2.setBalance(12000);
	
	new JdbcCrud().addAccount(a1);
	new JdbcCrud().addAccount(a2);
	
	new JdbcCrud().creditDebitAccount();
}
}

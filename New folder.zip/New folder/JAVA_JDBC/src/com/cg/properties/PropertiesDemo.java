package com.cg.properties;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesDemo {
public static void main(String[] args) throws IOException {
	Properties p=new Properties();
	//value from external file is fetched
	FileInputStream in=new FileInputStream("myprop.properties");
	p.load(in);
	System.out.println(p.getProperty("url"));
	
	//creates the file on own and values goes in it.
	/*p.put("url", "jdbc");
	p.put("uname", "system");
	FileOutputStream out=new FileOutputStream("app.properties");
	p.store(out, "saved");
	out.close();*/
	System.out.println("done");
	p.list(System.out);
}
}

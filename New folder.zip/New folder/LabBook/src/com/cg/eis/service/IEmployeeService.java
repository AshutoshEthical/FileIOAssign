package com.cg.eis.service;

public interface IEmployeeService 
{
 public abstract String insurance_scheme();
}

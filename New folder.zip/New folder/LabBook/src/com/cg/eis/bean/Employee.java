package com.cg.eis.bean;

import com.cg.eis.service.IEmployeeService;

public class Employee implements IEmployeeService 
{
 int id;
 String name;
 double Salary;
 String designation;
 
public Employee() {
	super();
}
public Employee(int id, String name, double salary, String designation) {
	super();
	this.id = id;
	this.name = name;
	Salary = salary;
	this.designation = designation;
}

public String insurance_scheme()
{
	if(Salary>5000 && Salary<20000 && designation.equals("System Associate"))
		return "Scheme C";
	if(Salary>=20000 && Salary<40000 && designation.equals("Programmer"))
		return "Scheme B";
	if(Salary>=40000 && designation.equals("Manager"))
		return "Scheme A";
	else
		return "No scheme";
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double getSalary() {
	return Salary;
}
public void setSalary(double salary) {
	Salary = salary;
}
@Override
public String toString() {
	return "Employee [id=" + id + ", name=" + name + ", Salary=" + Salary + "]";
}


 
}

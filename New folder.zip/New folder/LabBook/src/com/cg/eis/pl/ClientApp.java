package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.IEmployeeService;

public class ClientApp 
{
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter employee id");
	int id=sc.nextInt();
	System.out.println("enter employee name");
	String name=sc.next();
	System.out.println("enter salary");
	double sal=sc.nextDouble();
	System.out.println("enter designation");
	String desgn=sc.next();
	IEmployeeService e=new Employee(id,name,sal,desgn);
	String scheme=e.insurance_scheme();
    System.out.println(scheme);

}
}

package com.cg.labs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class lab7_2 
{
public static void main(String[] args) {
	ArrayList<String> al=new ArrayList<>();
	al.add("anu");
	al.add("aastha");
	al.add("vishad");
	al.add("manisha");
	al.add("adi");

    Collections.sort(al);
    
    for (String string : al) 
    {
		System.out.println(string);
	}
	
}
}

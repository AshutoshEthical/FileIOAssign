package com.cg.labs;

public interface lab7_3_IEmployee 
{
public abstract void addEmployee();
public abstract boolean deleteEmployee();
}

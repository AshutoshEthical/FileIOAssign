package com.cg.labs;

public class lab4_1_Person 
{
String name;
float age;



public lab4_1_Person() {
	super();
}
public lab4_1_Person(String name, float age) {
	super();
	this.name = name;
	this.age = age;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public float getAge() {
	return age;
}
public void setAge(float age) {
	this.age = age;
}
@Override
public String toString() {
	return "lab4_1_Person [name=" + name + ", age=" + age + "]";
}




}

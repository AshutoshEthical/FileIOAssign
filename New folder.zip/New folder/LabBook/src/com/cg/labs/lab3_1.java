package com.cg.labs;

import java.util.Scanner;

public class lab3_1 
{
 public static void main(String[] args) 
 {
	 String str;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the string");
	str=sc.nextLine();
	System.out.println("Enter the choice");
	char choice=sc.next().charAt(0);
	switch(choice)
	{
	case 'a': String str1=str;
	        for(int i=0;i<str.length();i++)
	        {
	        	char ch=str.charAt(i);
	        	str1=str1+ch;
	        }
	        System.out.println(str1);
	        break;
	case 'b':char ch1[]=str.toCharArray();
	       int l=ch1.length;
	       for(int i=0;i<l;i++)
	       {
	    	   if(i%2==1)
	    		   ch1[i]='#';
	       }
		  String str2=String.valueOf(ch1);
		  System.out.println(str2);
		  break;
   case 'c':char ch2[]=str.toCharArray();
           for(int i=0;i<ch2.length;i++)
           {
        	   for(int j=i+1;j<ch2.length;j++)
        	   {
        		   if(ch2[i]==ch2[j])
        			   ch2[j]='#';
        	   }
           }
           for(int i=0;i<ch2.length;i++)
           {
        	   if(ch2[i]!='#')
        	   System.out.print(ch2[i]);
	       }
           System.out.println();
           break;
   case 'd':char ch3[]=str.toCharArray() ;
           for(int i=0;i<ch3.length;i++)
           {
        	   if(i%2==1)
        		   ch3[i]=Character.toUpperCase(ch3[i]);
           }
           String str3=String.valueOf(ch3);
           System.out.println(str3);
           break;
     }
 }
}

package com.cg.labs;

public class lab5_3_AccPerson 
{
	public static void main(String[] args) 
	   {
	
		
	}
	}


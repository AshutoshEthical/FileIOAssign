package com.cg.labs;

import java.util.Scanner;

public class lab3_2 
{
 public static void main(String[] args) 
 {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the string");
	String str=sc.next();
	boolean res=positive(str);
	if(res==true)
	System.out.println("Positive string");
	else
		System.out.println("not a positive string");
}
 static boolean positive(String str)
 {
	 int i;
	int l=str.length();
	for(i=l-1;i>0;i--)
	{
		int ch=(int)str.charAt(i);
		int ch1=(int)str.charAt(i-1);
		if(ch<ch1)
			return false;
		else
			continue;
	}
	return true;
 }
}

package com.cg.labs;

public class lab2_5_Person {

}

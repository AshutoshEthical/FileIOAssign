package com.cg.labs;

import java.util.Scanner;

public class lab2_3_PersonMain 
{
 public static void main(String[] args) {
	 Scanner sc=new Scanner(System.in);
 //lab2_3_Person p1=new lab2_3_Person("Shahrukh","Khan",'M');
 System.out.println("Enter phone number");
 int phno=sc.nextInt();
 lab2_3_Person p1=new lab2_3_Person();
 p1.setFirstName("Shahrukh");
 p1.setLastName("khan");
 p1.setGender('M');
 p1.setPhno(phno);
 System.out.println("Person Details");
 System.out.println("________________________________");
 p1.display();
 
}
}

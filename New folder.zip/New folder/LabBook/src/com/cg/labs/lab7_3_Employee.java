package com.cg.labs;

public class lab7_3_Employee 
{

}

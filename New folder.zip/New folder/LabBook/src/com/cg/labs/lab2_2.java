package com.cg.labs;

public class lab2_2 {
public static void main(String[] args) 
{
	int no=Integer.parseInt(args[0]);
	if(no>0)
		System.out.println("positive");
	else
		System.out.println("negative");
}
}

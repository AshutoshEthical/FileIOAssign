package com.cg.labs;

public class lab2_3_Person 
{
String firstName;
String lastName;
char gender;
int phno;


public lab2_3_Person(String firstName, String lastName, char gender, int phno) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.gender = gender;
	this.phno = phno;
}
public lab2_3_Person() {
	// TODO Auto-generated constructor stub
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public char getGender() {
	return gender;
}
public void setGender(char gender) {
	this.gender = gender;
}


public int getPhno() {
	return phno;
}
public void setPhno(int phno) {
	this.phno = phno;
}
void display()
{
	System.out.println("First Name: "+firstName);
	System.out.println("Last Name: "+lastName);
	System.out.println("Gender: "+gender);
	System.out.println("PhoneNo: "+phno);
}
@Override
public String toString() {
	return "lab2_3_Person [firstName=" + firstName + ", lastName=" + lastName + ", gender=" + gender + "]";
}

}


package com.cg.labs;

public class lab4_2_CurrentAccount extends lab4_1_Account
{
	double overDraft_limit=1000;
	void withdraw(double withAmt)
{
	if((balance+overDraft_limit)<withAmt)
		System.out.println("insufficient balance");
	else
		System.out.println("allow withdraw");
}
}

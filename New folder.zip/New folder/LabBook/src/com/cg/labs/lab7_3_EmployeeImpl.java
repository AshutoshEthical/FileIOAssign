package com.cg.labs;

public class lab7_3_EmployeeImpl implements lab7_3_IEmployee
{

}

package com.cg.labs;

import java.util.Scanner;

public class lab2_1{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		String fname=sc.next();
		String lname=sc.next();
		char gender=sc.next().charAt(0);
		int age=sc.nextInt();
		double weight=sc.nextDouble();
		System.out.println("Person Details");
		System.out.println("__________________");
		System.out.println("First Name: "+fname);
		System.out.println("Last Name: "+lname);
		System.out.println("Gender: "+gender);
		System.out.println("Age: "+age);
		System.out.println("Weight: "+weight);
	}
}
package com.cg.labs;

import java.util.Scanner;

public class lab6_1_Exception1 
{
	public static void main(String[] args) 
	{
	Scanner sc=new Scanner(System.in);
	/*System.out.println("Enter first name");
	String fname=sc.next();
	System.out.println("enter last name");
	String lname=sc.next();*/
	String fname="";
	String lname="";
	System.out.println("enter gender");
	char gender=sc.next().charAt(0);
	System.out.println("enter phone number");
	int phno=sc.nextInt();
	check(fname,lname);
	}
	
	static void check(String fname,String lname)
	{
		if(fname.isEmpty()==true && lname.isEmpty()==true) 
			
			try {
				throw new checkException();
			} catch (checkException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		else
		{
			System.out.println("first name: "+fname);
		    System.out.println("last name: "+lname);
		}
	}
}

class checkException extends Exception
{
	public String getMessage()
	{
		return "first name and last name cannot be null";
	}
}
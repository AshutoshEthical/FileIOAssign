package com.cg.labs;

import java.util.Arrays;
import java.util.Scanner;

public class lab7_1 
{
public static void main(String[] args) 
{
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	String p[]=new String[n];
	for(int i=0;i<n;i++)
		p[i]=sc.next();
	Arrays.sort(p);
	for(int i=0;i<n;i++)
		System.out.println(p[i]);
}
}

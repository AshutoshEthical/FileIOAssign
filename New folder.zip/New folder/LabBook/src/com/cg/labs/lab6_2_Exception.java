package com.cg.labs;

import java.util.Scanner;

public class lab6_2_Exception 
{
	public static void main(String[] args) {
int age;
Scanner sc=new Scanner(System.in);
age=sc.nextInt();
check(age);
}
	public static String check(int age)
	{
		if(age<15)
		throw new ageException();
		else
			System.out.println(age);
			
	}
}
class ageException extends Exception
{
	
}
package com.cg.labs;

public class lab4_1_AccPerson 
{
   public static void main(String[] args) 
   {
	lab4_1_Account p=new lab4_1_Account();
	p.setName("smith");
	p.setAge(20);
	p.setBalance(20000);
	p.setAccNum(101011);
	p.deposit(2000);
	
	
	lab4_1_Account p1=new lab4_1_Account();
	p1.setName("kathy");
	p1.setAge(21);
	p1.setBalance(3000);
	p1.setAccNum(13932);
	p1.withdraw(2000);
	
	lab4_2_SavingsAccount p2=new lab4_2_SavingsAccount();
	p2.setBalance(3000);
	p2.withdraw(1000);
}
}

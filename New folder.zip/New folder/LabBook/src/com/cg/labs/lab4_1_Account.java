package com.cg.labs;

public class lab4_1_Account extends lab4_1_Person
{
long accNum;
double balance;
lab4_1_Person accHolder;


public lab4_1_Account() {
	super();
}
public lab4_1_Account(long accNum, double balance, lab4_1_Person accHolder) {
	super();
	this.accNum = accNum;
	this.balance = balance;
	this.accHolder = accHolder;
}
public long getAccNum() {
	return accNum;
}
public void setAccNum(long accNum) {
	this.accNum = accNum;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public lab4_1_Person getAccHolder() {
	return accHolder;
}
public void setAccHolder(lab4_1_Person accHolder) {
	this.accHolder = accHolder;
}
void deposit(double depAmt)
{
balance=balance+depAmt;
System.out.println(balance);
}
void withdraw(double WithAmt)
{
balance=balance-WithAmt;
System.out.println(balance);
}
@Override
public String toString() {
	return "lab4_1_Account [accNum=" + accNum + ", balance=" + balance + ", accHolder=" + accHolder + ", name=" + name
			+ ", age=" + age + "]";
}


}

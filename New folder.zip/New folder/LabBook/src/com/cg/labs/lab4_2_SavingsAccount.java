package com.cg.labs;

public class lab4_2_SavingsAccount extends lab4_1_Account
{
final double minBalance=1000;
void withdraw(double withAmt)
{
	if((balance-withAmt)<minBalance)
		System.out.println("insufficient balance");
	else
	{
		balance=balance-withAmt;
         System.out.println(balance);
	}
}}

package com.cg.Product;

public class Product 
{
 int barCode;
 String prdName;
 double prdCost;
 String Product;
 
 
public Product() {
	super();
	this.Product="Redmi";
}


public Product(int barCode, String prdName, double prdCost) {
	super();
	this.barCode = barCode;
	this.prdName = prdName;
	this.prdCost = prdCost;
	this.Product="Redmi";
}


public int getBarCode() {
	return barCode;
}


public void setBarCode(int barCode) {
	this.barCode = barCode;
}


public String getPrdName() {
	return prdName;
}


public void setPrdName(String prdName) {
	this.prdName = prdName;
}


public double getPrdCost() {
	return prdCost;
}


public void setPrdCost(double prdCost) {
	this.prdCost = prdCost;
}


public String getProduct() {
	return Product;
}


public void setProduct(String product) {
	Product = product;
}


@Override
public String toString() {
	return "Product [barCode=" + barCode + ", prdName=" + prdName + ", prdCost=" + prdCost + ", Product=" + Product
			+ "]";
}


public double billAmount(int qty) 
{
 double bA=prdCost*qty;
 return bA;

}

}
 

package com.cg.file.practice;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;

public class FileOutputStream1 
{
public static void main(String[] args) {
	FileOutputStream ofile=null;
	BufferedOutputStream bofile;
	byte b1[]= {'A','B','C'};
	try
	{
		ofile=new FileOutputStream("a2.txt");
		bofile=new BufferedOutputStream(ofile);                      
		bofile.write(b1);
		bofile.close();
	}
	catch(Exception e)
	{
		
	}
	System.out.println("hello");
}
}

package com.cg.file.practice;

import java.io.BufferedInputStream;
import java.io.FileInputStream;

public class FileInputStream1 
{
public static void main(String[] args) {
	FileInputStream ifile;
	BufferedInputStream bifile;
	try
	{
		ifile=new FileInputStream("a2.txt");
		bifile=new BufferedInputStream(ifile);
		int b=ifile.read();
		while(b!=-1)
		{
			System.out.println((char)b);
			b=ifile.read();
		}
		ifile.close();
	}
	catch(Exception e)
	{
		
	}
System.out.println("hii");
}
}

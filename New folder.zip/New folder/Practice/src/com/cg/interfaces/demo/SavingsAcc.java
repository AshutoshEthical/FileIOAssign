package com.cg.interfaces.demo;

public class SavingsAcc implements IAccount 
{
	int id;
	String name;
	double minBalance=2000;
	double Amt;

	
	public SavingsAcc() {
		super();
	}

	public SavingsAcc(int id, String name,  double amt) {
		super();
		this.id = id;
		this.name = name;
		Amt = amt;
	}
	@Override
	public void withdraw(double wAmt) 
	{
		// TODO Auto-generated method stub
		if(Amt-wAmt<minBalance)
			System.out.println("insufficient balance");
		else
		{
			double rBal=Amt-wAmt;
			System.out.println("Remaining balance is: "+rBal);
		}
		
	}
  

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}

	public double getAmt() {
		return Amt;
	}


	public void setAmt(double amt) {
		Amt = amt;
	}


	@Override
	public String toString() {
		return "SavingsAcc [id=" + id + ", name=" + name + ", minBalance=" + minBalance + ", Amt=" + Amt + "]";
	}




	
}

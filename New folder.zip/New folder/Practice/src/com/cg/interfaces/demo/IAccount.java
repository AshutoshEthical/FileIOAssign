package com.cg.interfaces.demo;

public interface IAccount 
{
	public final String bank_name= "HDFC BANK";
 public abstract void withdraw(double wAmt);
}

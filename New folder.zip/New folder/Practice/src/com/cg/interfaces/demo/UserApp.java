package com.cg.interfaces.demo;

public class UserApp 
{
public static void main(String[] args) {
	SavingsAcc s=new SavingsAcc();
	s.setAmt(5000);
	s.setId(101);
	s.setName("Vijay");
	s.withdraw(2000);
	
	IAccount a=new SavingsAcc(101,"Ajay",10000);
	a.withdraw(5000);
}
}

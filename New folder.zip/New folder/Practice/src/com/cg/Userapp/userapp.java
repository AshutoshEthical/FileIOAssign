package com.cg.Userapp;

import java.util.Scanner;

import com.cg.Product.Product;

public class userapp
{
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	Product p1=new Product(101,"note3",10000.00);
	System.out.println("Enter the quantity");
	int qty=sc.nextInt();
	double billAmt=p1.billAmount(qty);
	System.out.println("Your Bill Amount: "+billAmt);
	System.out.println(p1);
	
	System.out.println();
	
	Product p2=new Product();
	p2.setBarCode(102);
	p2.setPrdName("note4");
	p2.setPrdCost(20000.00);
	System.out.println("Enter the quantity");
	int qty1=sc.nextInt();
	double billAmt1=p2.billAmount(qty1);
	System.out.println("Your Bill Amount: "+billAmt1);
	System.out.println(p2);
	
}
}

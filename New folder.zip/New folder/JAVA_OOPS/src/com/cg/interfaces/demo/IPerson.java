package com.cg.interfaces.demo;

public interface IPerson 
{
 public abstract void calc();
	
}

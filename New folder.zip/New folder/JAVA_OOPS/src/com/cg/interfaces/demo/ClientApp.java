package com.cg.interfaces.demo;

import java.util.Scanner;

public class ClientApp {
public static void main(String[] args) {
	 Scanner sc=new Scanner(System.in);
	PermEmpImpl pemp=new PermEmpImpl();
	pemp.setEmpId(101);
	pemp.setBasicSal(3000);
	pemp.calc();
	/**************************************/
	TempEmpImpl temp=new TempEmpImpl();
	temp.setNoDays(20);
	temp.setSalPerDay(600);
	temp.setTempId(104);
	temp.calc();
	/*****************************************/
	System.out.println("enter emp id");
	int EmpId=sc.nextInt();
	System.out.println("enter basic sal");
	double BasicSal=sc.nextInt();
	IPerson p=new PermEmpImpl(EmpId,BasicSal);
	p.calc();
	/*******************************************/
	System.out.println("enter no of days worked");
	int noDays=sc.nextInt();
	System.out.println("enter salary per day");
	double SalPerDay=sc.nextInt();
	System.out.println("enter Temperorary id");
	int TempId=sc.nextInt();
	IPerson p1=new TempEmpImpl(TempId,SalPerDay,noDays);
	p1.calc();

}
}

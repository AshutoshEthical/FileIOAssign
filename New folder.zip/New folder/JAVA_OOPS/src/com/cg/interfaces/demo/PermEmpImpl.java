package com.cg.interfaces.demo;

public class PermEmpImpl implements IPerson
{
	int empId;
	double basicSal;

	
	
	public PermEmpImpl() {
		super();
	}

	public PermEmpImpl(int empId, double basicSal) {
		super();
		this.empId = empId;
		this.basicSal = basicSal;
	}

	@Override
	public void calc() {
		double tsal;
		// TODO Auto-generated method stub
		tsal=basicSal+1000;
		System.out.println(tsal);
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public double getBasicSal() {
		return basicSal;
	}

	public void setBasicSal(double basicSal) {
		this.basicSal = basicSal;
	}

	@Override
	public String toString() {
		return "PermEmpImpl [empId=" + empId + ", basicSal=" + basicSal + "]";
	}

	
}

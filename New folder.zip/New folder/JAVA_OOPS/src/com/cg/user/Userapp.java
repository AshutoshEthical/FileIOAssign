package com.cg.user;

import com.cg.entity.Student;

public class Userapp 
{
 public static void main(String[] args) 
 {
   Student s1=new Student(101,"jay",2000.00,40,80,90);//initialization using constructor
   
   //s1.setStuId(100);
   //s1.setStuName("Jay");
   //s1.setSal(3000.00);
   
   System.out.println(s1);
   char g=s1.findGrade();
   System.out.println("Grade secured: "+g);
   
   //initialization using getters and setters
   Student s2=new Student();
   s2.setStuId(101);
   s2.setStuName("Vijay");
   s2.setSal(4000.00);
   s2.setM1(30);
   s2.setM2(40);
   s2.setM3(50);
   
   System.out.println(s2);
   char g1=s2.findGrade();
   System.out.println("Grade secured: "+g1);
}
}

package com.cg.entity;

public class Student 
{
	public int stuId;
	public String stuName;
	public double sal;
	public String university;
	int m1,m2,m3;
	
	
	public Student(int stuId, String stuName, double sal, int m1, int m2, int m3) {
		super();
		this.stuId = stuId;
		this.stuName = stuName;
		this.sal = sal;
		this.m1 = m1;
		this.m2 = m2;
		this.m3 = m3;
		this.university = "Mumbai University";
	}
	public Student() {
		super();
		this.university = "Mumbai University";
	}
	
	public char findGrade()
	{
	  int total=m1+m2+m3;
	 double avg=(total/3.0);
	 System.out.println(total);
	 System.out.println(avg);
	 if(avg>=90)
		 return 'A';
	 if(avg>=80 && avg<90)
		 return 'B';
	 if(avg>=70 && avg<80)
		 return 'C';
	 else
		 return 'F';
	}
	public int getStuId() {
		return stuId;
	}
	public void setStuId(int stuId) {
		this.stuId = stuId;
	}
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	public String getUniversity() {
		return university;
	}
	public void setUniversity(String university) {
		this.university = university;
	}
	
	public int getM1() {
		return m1;
	}
	public void setM1(int m1) {
		this.m1 = m1;
	}
	public int getM2() {
		return m2;
	}
	public void setM2(int m2) {
		this.m2 = m2;
	}
	public int getM3() {
		return m3;
	}
	public void setM3(int m3) {
		this.m3 = m3;
	}
	@Override
	public String toString() {
		return "Student [stuId=" + stuId + ", stuName=" + stuName + ", sal=" + sal + ", university=" + university
				+ ", m1=" + m1 + ", m2=" + m2 + ", m3=" + m3 + "]";
	}
		

	
	
}

package com.dmart.shopping.service;

import java.util.ArrayList;

import com.dmart.shopping.entity.Product;

public interface IProduct 
{
 public abstract ArrayList<Product> addProducts(Product p);
}

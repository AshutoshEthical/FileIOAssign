package com.dmart.shopping.service;

import java.util.ArrayList;

import com.dmart.shopping.entity.Product;

public class ImplProduct implements IProduct
{
 ArrayList<Product> myList;
 public ImplProduct()
 {
	 myList=new ArrayList<Product>();
 }
@Override
public ArrayList<Product> addProducts(Product p) {
	// TODO Auto-generated method stub
	myList.add(p);
	return myList;
}
 
}

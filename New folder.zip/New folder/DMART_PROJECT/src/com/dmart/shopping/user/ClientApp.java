package com.dmart.shopping.user;

import java.util.ArrayList;
import java.util.Scanner;

import com.dmart.shopping.entity.Product;
import com.dmart.shopping.service.IProduct;
import com.dmart.shopping.service.ImplProduct;

public class ClientApp 
{
public static void main(String[] args) {
	String ans;
	int no;
	IProduct service=new ImplProduct();
	Scanner sc=new Scanner(System.in);
	do
	{
	System.out.println("*********************************");
	System.out.println("1.add products");
	System.out.println("2.show all products");
	System.out.println("3.search product by id");
	System.out.println("Enter your choice");
	no=sc.nextInt();
	switch(no)
	{
	case 1: System.out.println("Enter details of product");
	        System.out.println("Enter id: ");
	        int id=sc.nextInt();
	        System.out.println("enter name");
	        String name=sc.next();
	        System.out.println("enter cost");
	        float cost=sc.nextFloat();
	        Product p=new Product(id,name,cost);
	        ArrayList<Product> list=new ArrayList<>();
	        list=service.addProducts(p);
	        System.out.println(list);
	        break;
	case 2: System.out.println("babbbyyyyyyy");
	        break;
	case 3: System.out.println("inside case 3");
	        break;
	default: System.out.println("enter proper choice");        
	}
	System.out.println("do you wish to continue yes/no?");
    ans=sc.next();
	}while(ans.equals("yes")||ans.equals("y")||ans.equals("YES"));
}
}

package com.dmart.shopping.entity;

public class Product 
{
 int PrdId;
 String PrdName;
 float PrdCost;
 
public Product() {
	super();
}

public Product(int prdId, String prdName, float prdCost) {
	super();
	PrdId = prdId;
	PrdName = prdName;
	PrdCost = prdCost;
}

public Product(String prdName, float prdCost) {
	super();
	PrdName = prdName;
	PrdCost = prdCost;
}

public int getPrdId() {
	return PrdId;
}

public void setPrdId(int prdId) {
	PrdId = prdId;
}

public String getPrdName() {
	return PrdName;
}

public void setPrdName(String prdName) {
	PrdName = prdName;
}

public float getPrdCost() {
	return PrdCost;
}

public void setPrdCost(float prdCost) {
	PrdCost = prdCost;
}

@Override
public String toString() {
	return "Product [PrdId=" + PrdId + ", PrdName=" + PrdName + ", PrdCost=" + PrdCost + "]";
}
 

}

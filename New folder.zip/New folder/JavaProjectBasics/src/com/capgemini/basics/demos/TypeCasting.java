package com.capgemini.basics.demos;

public class TypeCasting
{
	public static void main(String[] args) {
		int x=5;
		int y=3;
		float res=x/y;//implicit type casting
		System.out.println(res);
		int a=5;
		int b=3;
		float res1=(float)x/y;//explicit type casting
		System.out.println(res1);
	}

}

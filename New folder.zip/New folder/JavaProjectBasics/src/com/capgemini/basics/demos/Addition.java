package com.capgemini.basics.demos;

import java.util.Scanner;

public class Addition {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num1, num2, res;
		System.out.println("Enter value for num1");
		num1=sc.nextInt();
		System.out.println("Enter value for num2");
		num2=sc.nextInt();
		res = num1 + num2;
		System.out.println("Addition of " +num1 + " and " +num2 + " is = "+res);
	      int x=5;
	      if(x==10)
	      {
	    	  System.out.println("inside if");
	    	  System.out.println("x is 10");
	      }
	      else
	      {
	    	  System.out.println("inside else");
	    	  System.out.println("x ix 5");
	      }
	    	  
	}
}

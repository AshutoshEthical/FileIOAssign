package com.capgemini.basics.demos;

import java.util.Scanner;

public class TestMaths 
{
   public static void main(String[] args) 
   {
	 int x,y;
     Scanner sc=new Scanner(System.in);
     System.out.println("enter the values");
	 x=sc.nextInt();
	 y=sc.nextInt();
     Maths m=new Maths();
     int res=m.sum(x,y);
     System.out.println("addition: "+res);
     int res1=m.sub(x,y);
     System.out.println("addition: "+res1);
}
}

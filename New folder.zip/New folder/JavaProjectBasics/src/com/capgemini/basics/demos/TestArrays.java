package com.capgemini.basics.demos;

import java.util.Scanner;

public class TestArrays
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int marks[]=new int[5];int t=0;
		for(int i=0;i<5;i++)
		{
			System.out.println("enter values");
			marks[i]=sc.nextInt();
			t=t+marks[i];
		}
		double avg=(double)t/5;
		System.out.println(t);
		System.out.println(avg);
	}

}

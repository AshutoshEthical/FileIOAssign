package com.capgemini.basics.demos;

import java.util.Scanner;

public class ternary 
{
  public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int age=18;
	String ans=(age>18)?"You can vote":"You cannot vote";
	System.out.println(ans);
	System.out.println("enter the values of a,b and c");
	int a=sc.nextInt();
	int b=sc.nextInt();
	int c=sc.nextInt();
	int d=(a>b)?((a>c)?a:c):((b>c)?b:c);
	System.out.println("greater number is: "+d);
}
}

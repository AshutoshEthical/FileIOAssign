package com.capgemini.basics.demos;

import java.util.Scanner;

public class Maths {
	
	int sum(int x,int y)
	{
		int res=x+y;
		return res;
		
	}
	
	int sub(int x,int y)
	{	
		int res=x-y;
		return res;
	}
}

package com.cg.testing;

public class Calculator {
int num1,num2;


public Calculator(int tdata1, int tdata2) {
	// TODO Auto-generated constructor stub
	num1=tdata1;
	num2=tdata2;
	
}
int add()
{
	return num1+num2;
}
public int divide()
{
	return num1/num2;
}
}

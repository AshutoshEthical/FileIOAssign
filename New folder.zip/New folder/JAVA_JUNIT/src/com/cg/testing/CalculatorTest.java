package com.cg.testing;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import junit.framework.Assert;

public class CalculatorTest {
	static Calculator c;
	@BeforeClass
	public static void preInit()
	{
		System.out.println("from before class ");
		int tdata1=10;
		int tdata2=5;
	 c=new Calculator(tdata1,tdata2);
	}
	
	
@Test
public void TestAdd()
{
	int expectedResult=15;
	//int tdata1=2;
	//int tdata2=3;
	//Calculator c=new Calculator(tdata1, tdata2);
	int actualResult=c.add();
	Assert.assertEquals(expectedResult, actualResult);
}

//tdd approach(prepARE UR TESTCASES first then prepare the code)....
@Test
public void testDivide1()
{
	int expectedResult=2;
	//int tdata1=10;
	//int tdata2=5;
	//Calculator c=new Calculator(tdata1, tdata2);
	int actualResult=c.divide();
	Assert.assertEquals(expectedResult, actualResult);
}
@Test(expected=ArithmeticException.class)
public void testDivide2()
{
	Calculator c1=new Calculator(10,0);
	int actualResult=c1.divide();
}

@AfterClass
public static void testaftercalss()
{
	System.out.println("from test after");
}
@Before
public void testAfter()
{
	System.out.println("from before");
}
@After
public void afterClass()
{
	System.out.println("from after");
}
}

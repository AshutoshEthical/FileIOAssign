package com.cg.collection.demo;


import java.util.*;

public class ArrayListDemo 
{
  public static void main(String[] args) {
	List<Student> myList=new ArrayList<Student>();
	//List<Number> mylist1=new ArrayList<Integer>();
	Student s1=new Student(101,"Jay",3000.00f);
	Student s2=new Student(102,"Vijay",4000.00f);
	Student s3=new Student(103,"Rahul",5000.00f);
	//Book b=new Book(101,"hello","hwdd","hdsgw");
	
	myList.add(s1);
	myList.add(s2);
	myList.add(s3);
	//myList.add(b);
	System.out.println(myList);
	
	System.out.println("using iterator:");
	Iterator<Student> it=myList.iterator();
	while(it.hasNext())
	{
		System.out.println(it.next());
	}
  }
}

package com.cg.collection.demo;

public class Student
{
 int stu_roll;
 String stu_name;
 float stu_fees;
 
 
public Student(int stu_roll, String stu_name, float stu_fees) {
	super();
	this.stu_roll = stu_roll;
	this.stu_name = stu_name;
	this.stu_fees = stu_fees;
}
public int getStu_roll() {
	return stu_roll;
}
public void setStu_roll(int stu_roll) {
	this.stu_roll = stu_roll;
}
public String getStu_name() {
	return stu_name;
}
public void setStu_name(String stu_name) {
	this.stu_name = stu_name;
}
public float getStu_fees() {
	return stu_fees;
}
public void setStu_fees(float stu_fees) {
	this.stu_fees = stu_fees;
}
@Override
public String toString() {
	return "Student [stu_roll=" + stu_roll + ", stu_name=" + stu_name + ", stu_fees=" + stu_fees + "]";
}
 
 
}

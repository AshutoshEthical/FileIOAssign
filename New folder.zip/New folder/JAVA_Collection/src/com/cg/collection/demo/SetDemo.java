package com.cg.collection.demo;

import java.util.HashSet;

public class SetDemo 
{
public static void main(String[] args) {
	HashSet s1=new HashSet();
	s1.add(10);
	s1.add("ram");
	s1.add(12.4);
	System.out.println(s1);
	
	HashSet<Integer> s2=new HashSet();
	s2.add(10);
	s2.add(20);
	s2.add(10);
	System.out.println(s2);
	System.out.println(s2.size());
}
}

package com.cg.collection.demo;

import java.util.ArrayList;

public class CollectionDemo1 
{
public static void main(String[] args) {
	ArrayList myList=new ArrayList();
	myList.add(100);
	myList.add(300);
	myList.add("Jay");
	myList.add(30.55);
	System.out.println(myList);
	
	myList.add(2,"Vijay");
	System.out.println(myList);
	myList.remove(3);
	System.out.println(myList);
}
}

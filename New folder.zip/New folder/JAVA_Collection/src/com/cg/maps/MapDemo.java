package com.cg.maps;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

public class MapDemo 
{
public static void main(String[] args) {
	HashMap hm=new HashMap();
	hm.put(1,'a');
	hm.put(2,'b');
	hm.put(3,'d');
    System.out.println(hm);
    
    Set ks=hm.keySet();
    for (Object o : ks) {
		//System.out.println(o);
    	//System.out.println(hm.get(o));
	}
    Set eset=hm.entrySet();
    for (Object object : eset) {
		Entry entry=(Entry)object;
		System.out.println(entry.getKey());
		System.out.println(entry.getValue());
	}
}
}

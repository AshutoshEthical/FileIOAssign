package com.cg.hashset;

import java.util.HashSet;

public class SetsDemo
{
	public static void main(String[] args) {
HashSet<Employee> s1=new HashSet<>();
Employee e1=new Employee();
e1.setEmpId(1001);
e1.setEmpName("raj");

Employee e2=new Employee();
e2.setEmpId(1001);
e2.setEmpName("raj");

System.out.println(e1.equals(e2));
System.out.println(e1.hashCode());
System.out.println(e2.hashCode());
s1.add(e1);
s1.add(e2);
System.out.println(s1.size());
}
}
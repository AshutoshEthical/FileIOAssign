package com.cg.hashset;

import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

 class Employee
{
 public Integer EmpId;
 public String EmpName;
 
 
public Employee() {
	super();
}
public Employee(int empId, String empName) {
	super();
	EmpId = empId;
	EmpName = empName;
}
public int getEmpId() {
	return EmpId;
}
public void setEmpId(int empId) {
	EmpId = empId;
}
public String getEmpName() {
	return EmpName;
}
public void setEmpName(String empName) {
	EmpName = empName;
}

public boolean equals(Object o)
{
	Employee emp=(Employee)o;
	boolean res=false;
	if((this.EmpId.equals(emp.EmpId)) && (this.EmpName.equals(emp.EmpName)))
	return true;
	return res;
		
}

public int hashCode()
{
	return this.EmpId;
}
@Override
public String toString() {
	return "Employee [EmpId=" + EmpId + ", EmpName=" + EmpName + "]";
}
}

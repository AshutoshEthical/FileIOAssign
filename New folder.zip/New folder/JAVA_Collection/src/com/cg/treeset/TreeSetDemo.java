package com.cg.treeset;

import java.util.TreeSet;

public class TreeSetDemo 
{
public static void main(String[] args) {
	
	TreeSet<Employee> ts=new TreeSet<>();
	Employee e1=new Employee();
	e1.setEmpId(1001);
	e1.setEmpName("raj");
	
	Employee e2=new Employee();
	e2.setEmpId(1002);
	e2.setEmpName("amit");
	
	ts.add(e1);
	ts.add(e2);
	System.out.println(ts.size());
}
}

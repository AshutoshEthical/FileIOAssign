package com.cg.io.file;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.ObjectInputStream;

class ObjectInputStreamDemo{


public static void main(String[] args) throws Exception {
	FileInputStream fis=new FileInputStream("stud.txt");
	ObjectInputStream ois=new ObjectInputStream(fis);
	Student s=(Student)ois.readObject();
	System.out.println(s.getRollNumber());
	System.out.println(s.getStudName());

}

}

package com.cg.io.file;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class ObjectStreamDemo {
public static void main(String[] args) throws IOException {
	Student s1=new Student();
	s1.setRollNumber(1001);
	s1.setStudName("adi");
	FileOutputStream fos=new FileOutputStream("stud.txt");
	ObjectOutputStream os=new ObjectOutputStream(fos);
	os.writeObject(s1);
	os.close();
	System.out.println("written");
}
}

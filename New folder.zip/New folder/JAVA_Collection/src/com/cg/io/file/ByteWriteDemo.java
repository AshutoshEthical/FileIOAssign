package com.cg.io.file;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteWriteDemo 
{
public static void main(String[] args)throws Exception
{
	FileOutputStream fos=new FileOutputStream("text.dat");
	BufferedOutputStream bos=new BufferedOutputStream(fos);
	/*bos.write(99);
	bos.write(100);
	bos.write('C');

	bos.close();
	System.out.println("ends");*/
	
	DataOutputStream dos=new DataOutputStream(bos);
	dos.writeInt(757);
	dos.writeDouble(327);
	dos.writeChar('C');
	dos.flush();
	System.out.println("ends");
	
}
}

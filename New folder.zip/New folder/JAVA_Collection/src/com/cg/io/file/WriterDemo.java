package com.cg.io.file;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class WriterDemo
{
public static void main(String[] args)throws Exception {
	FileWriter fw=new FileWriter("test2.txt");
	BufferedWriter bw=new BufferedWriter(fw);
	fw.write('c');
	fw.write('A');
	fw.close();
	System.out.println("jdxlkhfcds");
}
}

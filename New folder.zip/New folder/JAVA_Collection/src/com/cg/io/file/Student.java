package com.cg.io.file;

import java.io.Serializable;

public class Student implements Serializable{
int RollNumber;
String StudName;
public Student(int rollNumber, String studName) {
	super();
	RollNumber = rollNumber;
	StudName = studName;
}
public Student() {
	super();
}
public int getRollNumber() {
	return RollNumber;
}
public void setRollNumber(int rollNumber) {
	RollNumber = rollNumber;
}
public String getStudName() {
	return StudName;
}
public void setStudName(String studName) {
	StudName = studName;
}


}

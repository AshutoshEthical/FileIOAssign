package com.cg.io.file;

import java.io.BufferedReader;
import java.io.FileReader;

public class ReaderDemo {
public static void main(String[] args)throws Exception {
	FileReader fr=new FileReader("test2.txt");
	BufferedReader br=new BufferedReader(fr);
	int a=br.read();
	while(a!=-1) {
		System.out.println((char)a);
		a=br.read();
	}
}
}

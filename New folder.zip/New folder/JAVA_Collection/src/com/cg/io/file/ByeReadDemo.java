package com.cg.io.file;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;

public class ByeReadDemo {
public static void main(String[] args)throws Exception {
	FileInputStream fis=new FileInputStream("text.dat");
	BufferedInputStream bis=new BufferedInputStream(fis);
	DataInputStream dis=new DataInputStream(bis);
	int a=dis.readInt();
	double d=dis.readDouble();
	System.out.println(a);
	System.out.println(d);
	dis.close();
	/*int a=bis.read();
	while(a!=-1)
	{
		System.out.println(a);
		 a=bis.read();*/
}
}

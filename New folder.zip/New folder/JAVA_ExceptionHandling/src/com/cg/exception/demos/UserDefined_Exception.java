package com.cg.exception.demos;

public class UserDefined_Exception 
{
 public static void main(String[] args)
 {
	int n1=100;
	int n2=0;
	int result;
	try {
		result = callDiv(n1,n2);
		System.out.println(result);
	} catch (numException e) {
		// TODO Auto-generated catch block
		System.out.println(e.getMessage());
	}
	
}
 
 public static int callDiv(int n1,int n2)throws numException
 {
	 if(n2==0)
		 throw new numException();
	 else 
		 return n1/n2;
 }
}

class numException extends Exception
{
	public String getMessage()
	{
		 return "please check n2 has value zero";
	}
}

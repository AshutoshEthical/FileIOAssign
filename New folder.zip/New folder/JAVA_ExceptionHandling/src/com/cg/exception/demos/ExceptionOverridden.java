package com.cg.exception.demos;

public class ExceptionOverridden 
{
public static void main(String[] args)
{
	SuperClass1 s1=new Subclass1();
	s1.method1();
}
}

class SuperClass1
{
	void method1() throws RuntimeException
	{
		System.out.println("superclass");
	}
}

class Subclass1 extends SuperClass1
{
	void method1() throws ArithmeticException
	{
		System.out.println("subclass");
	}
}

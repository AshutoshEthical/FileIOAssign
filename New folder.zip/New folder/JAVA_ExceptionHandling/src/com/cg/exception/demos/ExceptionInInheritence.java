package com.cg.exception.demos;

public class ExceptionInInheritence 
{
public static void main(String[] args) 
{
superclass s=new subclass();
s.method();
}
}

class superclass
{
	void method()
	{
		System.out.println("hiii baby");
	}
}

class subclass extends superclass
{
	void method()throws ArithmeticException
	{
		System.out.println("hello darling");
	}
}

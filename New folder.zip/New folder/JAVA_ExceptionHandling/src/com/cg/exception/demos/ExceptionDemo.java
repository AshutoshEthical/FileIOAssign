package com.cg.exception.demos;

public class ExceptionDemo 
{

public static void main(String[] args)
{
	int k=100;
	try
	{
		int i=0;
		int j=k/i;
		System.out.println(j);
	}
	catch(Exception e)
	{
		System.out.println("please check value of i is zero");
		System.out.println(e.getMessage());
		e.printStackTrace();
	}
	System.out.println(k);
}
}

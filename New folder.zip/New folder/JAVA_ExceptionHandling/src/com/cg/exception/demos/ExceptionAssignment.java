package com.cg.exception.demos;

import java.util.Scanner;

public class ExceptionAssignment 
{
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter employee name");
	String empName=sc.next();
	System.out.println("enter Basic salary");
	double BasicSal=sc.nextDouble();
	double tax=0.1*BasicSal;
	double travAll=3000;
	double grosSal;
	try {
		grosSal = findGrossSal(empName,BasicSal,travAll,tax);
		System.out.println(grosSal);
	} catch (SalException e) {
		// TODO Auto-generated catch block
		System.out.println(e.getMessage());
	}
}

public static double findGrossSal(String empName,double BasicSal,double travlAll,double tax)throws SalException
{
	if(BasicSal<10000)
		throw new SalException();
	else
	{
		double grossSal=BasicSal-travlAll-tax;
	    return grossSal;
	}
}
}

class SalException extends Exception
{
	public String getMessage()
	{
		return "Employee salary cannot be less than 10000";
	}
}
